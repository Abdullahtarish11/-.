import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(PrayerApp());
}

class PrayerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مواقيت الصلاة',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: SelectCityScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class SelectCityScreen extends StatefulWidget {
  @override
  _SelectCityScreenState createState() => _SelectCityScreenState();
}

class _SelectCityScreenState extends State<SelectCityScreen> {
  final List<String> countries = ['Saudi Arabia', 'Egypt', 'UAE'];
  final Map<String, List<String>> cities = {
    'Saudi Arabia': ['Riyadh', 'Jeddah', 'Dammam'],
    'Egypt': ['Cairo', 'Alexandria', 'Giza'],
    'UAE': ['Dubai', 'Abu Dhabi', 'Sharjah'],
  };

  String selectedCountry = 'Saudi Arabia';
  String selectedCity = 'Riyadh';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('اختيار المدينة')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButton<String>(
              value: selectedCountry,
              isExpanded: true,
              items: countries.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (value) {
                setState(() {
                  selectedCountry = value!;
                  selectedCity = cities[selectedCountry]!.first;
                });
              },
            ),
            SizedBox(height: 16),
            DropdownButton<String>(
              value: selectedCity,
              isExpanded: true,
              items: cities[selectedCountry]!.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (value) {
                setState(() {
                  selectedCity = value!;
                });
              },
            ),
            SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => PrayerTimesScreen(
                      city: selectedCity,
                      country: selectedCountry,
                    ),
                  ),
                );
              },
              child: Text('عرض مواعيد الصلاة'),
            ),
          ],
        ),
      ),
    );
  }
}

class PrayerTimesScreen extends StatefulWidget {
  final String city;
  final String country;

  PrayerTimesScreen({required this.city, required this.country});

  @override
  _PrayerTimesScreenState createState() => _PrayerTimesScreenState();
}

class _PrayerTimesScreenState extends State<PrayerTimesScreen> {
  Map<String, String> prayerTimes = {};
  String date = '';

  @override
  void initState() {
    super.initState();
    fetchPrayerTimes();
  }

  Future<void> fetchPrayerTimes() async {
    final url =
        'https://api.aladhan.com/v1/timingsByCity?city=${widget.city}&country=${widget.country}&method=4';

    final response = await http.get(Uri.parse(url));
    final data = json.decode(response.body);

    setState(() {
      final timings = data['data']['timings'];
      final gregorian = data['data']['date']['gregorian']['date'];
      final hijri = data['data']['date']['hijri']['date'];
      date = "$gregorian / $hijri";
      prayerTimes = {
        'الفجر': timings['Fajr'],
        'الشروق': timings['Sunrise'],
        'الظهر': timings['Dhuhr'],
        'العصر': timings['Asr'],
        'المغرب': timings['Maghrib'],
        'العشاء': timings['Isha'],
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('مواقيت الصلاة - ${widget.city}'),
        centerTitle: true,
      ),
      body: prayerTimes.isEmpty
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text('${widget.country}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text(date, style: TextStyle(fontSize: 16)),
                  SizedBox(height: 20),
                  ...prayerTimes.entries.map((entry) => Card(
                        child: ListTile(
                          title: Text(entry.key, style: TextStyle(fontWeight: FontWeight.bold)),
                          trailing: Text(entry.value),
                        ),
                      )),
                ],
              ),
            ),
    );
  }
}
